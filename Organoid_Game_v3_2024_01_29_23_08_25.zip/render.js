//https://editor.p5js.org/manno/sketches/iX61TJgRv


//Render Health Bar
function renderHealth() {
  if(status=="HEALTHY")fill(color(0,155,0));
  if(status=="ABNORMAL")fill("#90682f");
  if(status=="DYING")fill(color(255,0,0));
  text(status, 170,40);
}

//Render Sterility Bar (currently isnt dynamic)
function renderSterility(s) {
  if(contamrisk=="LOW")fill(color(0,155,0));
  if(contamrisk=="MODERATE")fill("#90682f");
  if(contamrisk=="EXTREME")fill(color(255,0,0));
  text(contamrisk, 210,80);
}

function addUnits(textN){
  if(textN=="CEPT")textN+=" 50ul"
  if(textN=="IWR1")textN+=" 50ul"
  if(textN=="EGF")textN+=" 50ul"
  if(textN=="FGF")textN+=" 50ul"
  if(textN=="SB-431542")textN+=" 50ul"
  if(textN=="NT3")textN+=" 50ul"
  if(textN=="DMEM")textN+=" 500ml"
  if(textN=="Lipid Concentrate")textN="Lipid Conc. 5ml"
  if(textN=="PenStrep")textN+=" 5ml"
  if(textN=="Fungizone")textN+=" 5ml"
  if(textN=="Brainphys")textN+=" 500ml"
  if(textN=="BDNF")textN+=" 50ul"
  if(textN=="FBS")textN+=" 50ul"
  if(textN=="Heperin")textN+=" 5ml"
  if(textN=="B27")textN+=" 10ml"
  if(textN=="Aggrewell")textN+=" 500ml"
  if(textN=="N2")textN+=" 5ml"
  return textN;
}

//Render media bar
function renderMedia(l) {
  noStroke();
  for(let i=0;i<maxFill;i++){
     fill(color(255,255,255));
     stroke(0)
     strokeWeight(2)
     rect(480,20,170,320)
  }
  for(let i=0;i<l;i++){
     stroke(0)
     strokeWeight(2)
     if(addUnits(mixture[i]).includes("50ul")){
       fill("#0EAD69")
       rect(480,340-fiftyul-used,170,20);
       noStroke()
       fill(0)
       text(addUnits(mixture[i]),660,340-fiftyul-used+15);
       used+=20;
     } 
     else if(addUnits(mixture[i]).includes("5ml") || addUnits(mixture[i]).includes("10ml")){
       fill("#FFD23F")
       rect(480,340-fiveml-used,170,30);
       noStroke()
       fill(0)
       text(addUnits(mixture[i]),660,340-fiveml-used+25);
       used+=30
     }
     else {
        fill("#540D6E")
        rect(480,340-70-used,170,70);
        noStroke()
        fill(0)
        text(addUnits(mixture[i]),660,340-100-used+70);
        used+=70
     }
     if(used>320){
       mixture = []
       print("OVERFLOW WARNING");
       fillLevel=0;
       createOopsie("You overflowed the media container and made a huge mess! Your space has become less sterile.");
       downgradeContam();
     }
     noStroke();
     fill(0);
     fill(255,255,255);
  }
  used = 0;
  noStroke();
}

//Drop down menu for compounds
function renderSelectCompound() {
  sel = createSelect();
  sel.position(10, 400);
  sel.option("IWR1");
  sel.option("EGF");
  sel.option("BDNF");
  sel.option("FGF");
  sel.option("SB-431542");
  sel.option("NT3");
  sel.option("DMEM");
  sel.option("N2");
  sel.option("Lipid Concentrate");
  sel.option("PenStrep");
  sel.option("Fungizone");
  sel.option("Brainphys");
  sel.option("FBS");
  sel.option("Heperin");
  sel.option("B27");
  sel.option("Aggrewell");
  //sel.changed(updateState);
}
function setCM(){
  if(carryMix.length>1){
     cM=true;
    updateState();
  }
}

function emptyM(){
  mixture = [];
  fillLevel = 0;
}

//Add to mixture button
function renderAddButton() {
  addButton = createButton("Add to mixture");
  addButton.position(145, 400);
  addButton.mousePressed(updateState);
}
//carryover button
function renderCarryButton() {
  loadButton = createButton("Load Previous Mixture");
  loadButton.position(480, 400);
  loadButton.mousePressed(setCM);
}
//carryover button
function renderEmptyButton() {
  empB = createButton("Empty Current Mixture");
  empB.position(480, 425);
  empB.mousePressed(emptyM);
}
//feed button
function renderFeedButton() {
  feedButton = createButton("Feed Current Mixture");
  feedButton.position(480, 450);
  feedButton.mousePressed(feedOrganoid);
}

function flipBools(mixture){
  if(mixture.includes("CEPT"))CEPT=true; 
  if(mixture.includes("IWR1"))IWR1=true;
  if(mixture.includes("EGF"))EGF=true;
  if(mixture.includes("FGF"))FGF=true;
  if(mixture.includes("SB-431542"))SB431542=true;
  if(mixture.includes("NT3"))NT3=true; 
  if(mixture.includes("DMEM"))DMEM=true;
  if(mixture.includes("BDNF"))BDNF=true;
  if(mixture.includes("Lipid Concentrate"))lipidconcentrate=true; 
  if(mixture.includes("PenStrep"))penstrep=true;
  if(mixture.includes("Fungizone"))fungizone=true;
  if(mixture.includes("Brainphys"))brainphys=true;
  if(mixture.includes("FBS"))FBS=true;
  if(mixture.includes("Heperin"))heperin=true;
  if(mixture.includes("B27"))B27=true;
  if(mixture.includes("Aggrewell"))aggrewell=true;
  if(mixture.includes("N2"))N2=true;
  chems=[CEPT,IWR1,EGF,BDNF,FGF,SB431542,NT3,DMEM,N2,lipidconcentrate,penstrep,fungizone,brainphys,FBS,heperin,B27,aggrewell];
}

//updates how much liquid based on volume selected
function updateState() {
  if(cM){
    mixture=carryMix;
    flipBools(mixture);
    fillLevel = carryMix.length;
    cM = false;
  }
  if(!mixture.includes(sel.selected())){
    mixture[mixture.length] = sel.selected();
    flipBools(mixture);
    if(fillLevel<15){
      fillLevel += 1;
    }
  
  } else {
    //add OVERFILL CONDIDITON
  }
}

//Feed organoid function
function feedOrganoid() {
  print(mixture);
  carryMix=mixture;
  media();
  fillLevel = 0;
  mixture = [];
  if(dayN<=7){
    dayN+=1;
  } else {
    dayN +=2;
  }
  print(organoidSize)
  changeSize();
}

function setAllFalse(){
  CEPT=false; IWR1=false; EGF=false; BDNF=false; FGF=false; SB431542=false; NT3=false; DMEM=false;
N2=false; lipidconcentrate=false; penstrep=false; fungizone=false; brainphys=false; FBS=false;
heperin=false; B27=false; aggrewell=false;
}

function media() {
  let ran = int(random(qs.length));
  let qChoice = qs[ran];
  print(qChoice);
  media1 = CEPT && aggrewell;
  media2 = aggrewell && IWR1 && SB431542;
  sasai2 = DMEM && N2 && lipidconcentrate && penstrep && fungizone;
  galina3a = brainphys && N2 && lipidconcentrate && penstrep && fungizone && FBS && heperin && EGF && FGF;
  galina3 = brainphys && N2 && lipidconcentrate && penstrep && fungizone && FBS && heperin;
  galina4a = brainphys && N2 && lipidconcentrate && penstrep && fungizone && FBS && heperin && B27 && BDNF && NT3;
  galina4 = brainphys && N2 && lipidconcentrate && penstrep && fungizone && FBS && heperin && B27;
  print(galina3a);
  if(dayN==0 && media1){
    print("YAY MEDIA 1");
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
          
    }
  }
  else if(dayN>=1 && dayN<=17 && media2){
    print("YUH MEDIA 2")
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else if(dayN>17 && dayN<=35 && sasai2){
    print("WOO SASAI2")
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else if(dayN>35 && dayN<=42 && galina3a){
    print("UHHH GALINA3A")
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else if(dayN>42 && dayN<70 && galina3){
    print("EEEE GALINA3")
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else if(dayN>69 && dayN<77 && galina4a){
    print("OOOOO GALINA4a")
   if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else if(dayN>76 && galina4){
    print("UUUUU GALINA4")
    if(random(3)<1){
          createPopUp(qChoice[0],qChoice[1],qChoice[2],qChoice[qChoice[3]],qChoice[4]);
    }
  }
  else{
    downgradeGrowth();
  }
  setAllFalse();
}

function renderWarning(warning,butt) {
  background(220);
  noStroke();
  fill(0);
  textSize(50);
  text(warning, 20, 40);
  hideButtons();
  if (!buttonBool) {
    okButton = createButton(butt);
    okButton.position(340, 400);
    okButton.mousePressed(function () {
      warn = true;
      okButton.hide();
      ini = false;
    });
    buttonBool = true;
  }
}

function hideButtons() {
  addButton.hide();
  feedButton.hide();
  sel.hide();
  loadButton.hide();
}

function showButtons() {
  addButton.show();
  feedButton.show();
  sel.show();
  loadButton.show();
}

function createOopsie(message){
  let div = createDiv(message);
  div.style('font-size', '50px');
  div.style('background-color',color(255,255,255))
  div.style('height','500px')
  div.style('width','650px')
  div.style('border-style','solid');
  div.position(10, 10);
  bb = createButton("OK");
  bb.position(300, 400);
  bb.mousePressed(function () {
      bb.hide();
      div.hide();
    })
}

function createend(message){
  let div = createDiv(message);
  div.style('font-size', '50px');
  div.style('background-color',color(255,255,255))
  div.style('height','500px')
  div.style('width','650px')
  div.style('border-style','solid');
  div.position(10, 10);
}

function downgradeGrowth(){
  if(status=="DYING"){
    print("DEAD CHECK HERE")
    createend("Your organoid had died due to unhealthy growth patterns. Please reset the game by reloading the page and try again.")
  }
  if(status=="ABNORMAL"){
    status="DYING"
  }
  if(status=="HEALTHY"){
    status="ABNORMAL"
  }
  organoidSize*=0.75
}

function downgradeContam(){
  if(contamrisk=="EXTREME"){
    print("DEAD CHECK HERE")
    createend("Your organoid had died due to unsterile cell culturing conditions. Please reset the game by reloading the page and try again.")
  }
  if(contamrisk=="MODERATE"){
    contamrisk="EXTREME"
  }
  if(contamrisk=="LOW"){
    contamrisk="MODERATE"
  }
  organoidSize*=0.75
}

function createPopUp(message,op1,op2,answer,wrongmess){
  let div = createDiv(message);
  div.style('font-size', '50px');
  div.style('background-color',color(255,255,255))
  div.style('height','500px')
  div.style('width','650px')
  div.style('border-style','solid');
  div.position(10, 10);
  trueB = createButton(op1);
  falseB = createButton(op2);
    trueB.position(50, 400);
    trueB.mousePressed(function () {
      if(answer==op2){
        createOopsie("Your contamination risk has increased.")
        createOopsie(wrongmess);
        downgradeContam();
      }
      div.hide();
      trueB.hide();
      falseB.hide();
    })

    falseB.position(300, 400);
    falseB.mousePressed(function () {
      if(answer==op1){
        createOopsie("Your contamination risk has increased.")
        createOopsie(wrongmess);
        downgradeContam();
      }
      div.hide();
      trueB.hide();
      falseB.hide();
    })
}

function fact() {
  if(dayN<18) return("your organoid is undergoing neural induction");
  if(dayN>17 && dayN<36) return("your organoid is undergoing differentiation")
  if(dayN>35 && dayN<70) return("your organoid is undergoing the first part\n                           of the maturation process");
  if(dayN>69) return("your organoid is finishing the maturation process")
  if(dayN>70) createend("You have successfully cultured a simulated brain organoid to maturation!")
}

function getPicfromStatus(){
  if(dayN<7) return day3;
  if(dayN>6 && dayN<14) return day7;
  if(dayN>13 && dayN<28) return day14;
  if(dayN>27 && dayN<41) return day28;
  if(dayN>40 && dayN<44) return day42;
  if(dayN>43 && dayN<55) return day45;
  if(dayN>54 && dayN<72) return day70;
  if(dayN>71) return day73;
}

function drawOrganoid(size){
  push();
    stroke(1);
    fill(161,138,107)
    circle(130,250,size);
  pop();
}

//data for 15-22 here: https://docs.google.com/spreadsheets/d/1r1Dxptpph0h9hoWYdO-YJHF59QPWmy8kkvu1KLx3WWI/edit?usp=sharing
function changeSize(){
  if(dayN<=15) organoidSize*=random(1.0752,1.4309)
  if(dayN==16) organoidSize*=random(1.0306,1.3312)
  if(dayN==17) organoidSize*=random(1.0,1.2260)
  if(dayN==18) organoidSize*=random(0.9876,1.146)
  if(dayN==19) organoidSize*=random(1.011,1.234)
  if(dayN==20) organoidSize*=random(0.9447,1.1805)
  if(dayN==21) organoidSize*=random(0.9656,1.1560)
  if(dayN==22) organoidSize*=random(0.9643,1.1554)
  if(dayN>22 && dayN<28) organoidSize*=1.12
  if(dayN>27 && dayN<36) organoidSize*=1.0116
  if(dayN>35 && dayN<41) organoidSize*=1.0133
  if(dayN>40 && dayN<46) organoidSize*=1.00433
  if(dayN>45 && dayN<57) organoidSize*=1.00898
  if(dayN>56 && dayN<71) organoidSize*=1.0042
  if(dayN>70 && dayN<74) organoidSize*=1.02247
}

function initGame() {
  buttonBool = false;
  showButtons();
  fill(0);
  background(220);
  textSize(20);
  noStroke();
  text("Growth Status", 20, 40);
  text("Contamination Risk", 20, 80);
  text("Day " + dayN, 20, 120);
  let ima = getPicfromStatus()
  ima.resize(200, 266);
  image(ima, 250, 110);
  drawOrganoid(organoidSize);
  renderHealth();
  renderMedia(fillLevel);
  renderSterility();
  stroke(0);
  fill(255)
  noStroke();
  fill(0);
  text("Current Status: " + fact(),100,450)
}