var dayN = 2;
let sel;
let ini = true;
let addButton;
let mixture = [];
let carryMix = [];
let feedButton;
let fillLevel = 0;
let maxFill = 10;
let warn = true;
let buttonBool = false;
let okButton;
let startButton;
let empB;
let dead = false;
let success;
let organoidSize = 10;
//load previous mixture usage boolean
let cM = false;
//substances
let CEPT=false; IWR1=false; EGF=false; BDNF=false; FGF=false; SB431542=false; NT3=false; DMEM=false;
let N2=false; lipidconcentrate=false; penstrep=false; fungizone=false; brainphys=false;
let heperin=false; B27=false; aggrewell=false;FBS = false;
let chems = [];
//media status booleans
let media1 = false;
let media2 = false;
let sasai2 = false;
let galina3 = false;
let galina3a = false;
let galina4 = false;
let galina4a = false;
//organoid images
let healthypic, abnormalpic, dyingpic;
let day3, day7, day14, day18, day28, day42, day45, day70, day73;
//starter statuses
let status = "HEALTHY";
let contamrisk = "LOW";
//for creating dynamically shaped media blobs
let remain = 500;
let used = 0;
let fiftyul = 20;
let fiveml = 30;
let full = 370;


function preload() {
  day3 = loadImage('assets/day3.jpeg');
  day7 = loadImage('assets/day7-1.jpg');
  day14 = loadImage('assets/day14-1.jpg');
  day18 = loadImage('assets/day18-1.jpg');
  day28 = loadImage('assets/day28-1.jpg');
  day42 = loadImage('assets/day42-1.jpg');
  day45 = loadImage('assets/day45-1.jpg');
  day70 = loadImage('assets/day70-1.jpg');
  day73 = loadImage('assets/day73-1.jpg');
}

function setup() {
  createCanvas(850, 550);
  background(220);
  renderSelectCompound();
  renderAddButton();
  renderFeedButton();
  renderEmptyButton();
  renderCarryButton();
}

function draw() {


      initGame();
}
