function title() {
  textStyle(BOLD);
  textAlign(CENTER);
  textSize(30);
  text("Reference Guide", 375, 40);
}
function preload() {
  imgSchedule = loadImage('assets/new_sched3.PNG');
}

function medias() {
  textStyle(BOLD);
  textSize(25);
  text("Medias", 50, 525);
}

function renderAggrewellButton() {
  AggrewellButton = createButton("Aggrewell");
  AggrewellButton.position(buttonX, buttonY);
  AggrewellButton.style("font-size", "20px");
  AggrewellButton.mousePressed(Aggrewellinfo);
}

function Aggrewellinfo() {
 media = 0;
}
function renderBrainphysButton() {
  BrainphysButton = createButton("Brainphys");
  BrainphysButton.position(buttonX, buttonY + buttonOffset);
  BrainphysButton.style("font-size", "20px");
  BrainphysButton.mousePressed(Brainphysinfo);
}

function Brainphysinfo() {
 media = 1;
}

function renderDMEMButton() {
  DMEMButton = createButton("DMEM/F12");
  DMEMButton.position(buttonX, buttonY + (buttonOffset *2));
  DMEMButton.style("font-size", "20px");
  DMEMButton.mousePressed(DMEMinfo);
}

function DMEMinfo() {
 media = 2;
}

//chemical inhibitors
function chemicalInhibitors() {
  textStyle(BOLD);
  textSize(25);
  text("Chemical Inhibitors", 320, 525);
}




function renderSBButton() {
  SBButton = createButton("SB-431542");
  SBButton.position(buttonX+200, buttonY+ buttonOffset);
  SBButton.style("font-size", "20px");
  SBButton.mousePressed(SBinfo);
}

function SBinfo() {
 media = 4;
}
function renderIWR1Button() {
  IWR1Button = createButton("IWR1");
  IWR1Button.position(buttonX+200, buttonY+ (buttonOffset-30));
  IWR1Button.style("font-size", "20px");
  IWR1Button.mousePressed(IWR1info);
}

function IWR1info() {
   media = 5;
}
//Recombinant Proteins:

function recombinantProteins() {
  textStyle(BOLD);
  textSize(25);
  text("Growth Factors", 635, 655);
}

function renderEGFButton() {
  EGFButton = createButton("EGF");
  EGFButton.position(buttonX+500, buttonY+(buttonOffset*4));
  EGFButton.style("font-size", "20px");
  EGFButton.mousePressed(EGFinfo);
}

function EGFinfo() {
   media = 6;
}
function renderBDNFButton() {
  BNDFButton = createButton("BDNF");
  BNDFButton.position(buttonX+500, buttonY +(buttonOffset*5));
  BNDFButton.style("font-size", "20px");
  BNDFButton.mousePressed(BDNFinfo);
}

function BDNFinfo() {
   media = 7;
}

function FGFbinfo() {
   media = 8;
}

function renderFGFbButton() {
  FGFBButton = createButton("FGFb");
  FGFBButton.position(buttonX+500, buttonY +(buttonOffset *6));
  FGFBButton.style("font-size", "20px");
  FGFBButton.mousePressed(FGFbinfo);
}





function renderNT3Button() {
  NT3Button = createButton("NT3");
  NT3Button.position(buttonX+500, buttonY +(buttonOffset *7));
  NT3Button.style("font-size", "20px");
  NT3Button.mousePressed(NT3info);
}

function NT3info() {
 media = 9;
}



//Extracellular Matrix
function extracellularMatrix() {
  textStyle(BOLD);
  textSize(25);
  text("Anti-coagulant", 325, 650);
}

function renderHeperinButton() {
  HeperinButton = createButton("Heparin");
  HeperinButton.position(buttonX+200, buttonY + (buttonOffset *4));
  HeperinButton.style("font-size", "20px");
  HeperinButton.mousePressed(Heperininfo);
}

function Heperininfo() {
 media = 10;
}

//Supplements
function supplements() {
  textStyle(BOLD);
  textSize(25);
  text("Supplements", 90, 655);
}

function renderN2Button() {
  N2Button = createButton("N2");
  N2Button.position(buttonX,  buttonY +(buttonOffset *4));
  N2Button.style("font-size", "20px");
  N2Button.mousePressed(N2info);
}

function N2info() {
 media = 11;
}
function renderB27Button() {
  B27Button = createButton("B27");
  B27Button.position(buttonX, buttonY +(buttonOffset *5));
  B27Button.style("font-size", "20px");
  B27Button.mousePressed(B27info);
}

function B27info() {
 media = 12;
}
function renderFBSButton() {
  FBSButton = createButton("FBS");
  FBSButton.position(buttonX, buttonY +(buttonOffset *6));
  FBSButton.style("font-size", "20px");
  FBSButton.mousePressed(FBSinfo);
}

function FBSinfo() {
 media = 13;
}
function renderLipidButton() {
  LipidButton = createButton("Lipid Concentrate");
  LipidButton.position(buttonX, buttonY +(buttonOffset *7));
  LipidButton.style("font-size", "20px");
  LipidButton.mousePressed(Lipidinfo);
}

function Lipidinfo() {
 media = 14;
}

//Anti-contamination:
function extracellularMatrix() {
  textStyle(BOLD);
  textSize(25);
  text("Extracellular Matrix", 325, 655);
}

function antiContamination() {
  textStyle(BOLD);
  textSize(25); 
  text("Anti-contamination", 625, 525);
  
}

function renderPenStrepButton() {
  PenStrepButton = createButton("PenStrep");
  PenStrepButton.position(buttonX+500, buttonY);
  PenStrepButton.style("font-size", "20px");
  PenStrepButton.mousePressed(PenStrepinfo);
}

function PenStrepinfo() {
 media = 15;
}

function renderFungizoneButton() {
  FungizoneButton = createButton("Fungizone");
  FungizoneButton.position(buttonX+500, buttonY +(buttonOffset));
  FungizoneButton.style("font-size", "20px");
  FungizoneButton.mousePressed(Fungizoneinfo);
}

function Fungizoneinfo() {
 media = 16;
}

function renderScheduleButton(){
  scheduleButton = createButton("Schedule");
  scheduleButton.position(380,60 );
  scheduleButton.style("font-size", "20px");
  scheduleButton.mousePressed(scheduleInfo);
}
function scheduleInfo() {
  media = 17; 
}

function renderHowToPlayButton(){
  howToPlayButton = createButton("How to Play");
  howToPlayButton.position(250,60 );
  howToPlayButton.style("font-size", "20px");
  howToPlayButton.mousePressed(howToInfo);
}

function howToInfo() {
  media = 18; 
}


//function mouseClicked() {
//  if (isMouseInsideText(message, messageX, messageY)) {
//    window.open('https://blacklivesmatter.com/', '_blank');
//  }
//}

//function isMouseInsideText(message, messageX, messageY) {
//  const messageWidth = textWidth(message);
//  const messageTop = messageY - textAscent();
//  const messageBottom = messageY + textDescent();

//  return mouseX > messageX && mouseX < messageX + messageWidth &&
//    mouseY > messageTop && mouseY < messageBottom;
//}
