let CEPTButton;
let IWR1Button;
let EGFButton;
let BNDFButton;
let FGFButton;
let SBButton;
let NT3Button;
let buttonX = 30;
let buttonY = 540;
let DMEMButton;
let N2Button;
let LipidButton;
let PenStrepButton;
let FungizoneButton;
let BrainphysButton;
let FBSButton;
let HeperinButton;
let B27Button;
let AggrewellButton;
let media;
let textX = 50;
let textY = 200;
let textXBox = 700;
let textYBox = 300;
let descriptionTextSize = 20;
let buttonOffset = 30;
let howToPlayButton;
let scheduleButton;
let imgSchedule;

function setup() {
  createCanvas(800, 800);
  background(220);
  renderIWR1Button();
  renderEGFButton();
  renderBDNFButton();
  renderFGFbButton();
  renderSBButton();
  renderNT3Button();
  renderDMEMButton();
  renderN2Button();
  renderLipidButton();
  renderPenStrepButton();
  renderFungizoneButton();
  renderBrainphysButton();
  renderFBSButton();
  renderHeperinButton();
  renderB27Button();
  renderAggrewellButton();
  renderScheduleButton();
  renderHowToPlayButton();
}

function draw() {
  fill(0);
  background(220);
  title();
  medias();
  chemicalInhibitors();
  recombinantProteins();
  extracellularMatrix();
  supplements();
  antiContamination();
  switch (media) {
    case 0:
      //Aggrewell
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      textWrap(WORD);
      text(
        "Aggrewell is a proprietary media (STEMCELL Technologies) that supports stem cell growth and expansion without preventing differentiation.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      noStroke();
      break;

    case 1:
      //Brainphys
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      textWrap(WORD);
      text(
        "Brainphys is a media that has been formulated to have a more physiological level of carbohydrates. It has been shown to increase a neuron's electrophysiological activity in cultures.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      noStroke();
      break;

    case 2:
      //DMEM
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      textWrap(WORD);
      text(
        "DMEM/F-12 is the standard base media for neuronal cultures. Supplies the basic carbohydrates and amino acids required for neuronal growth.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 3:
     

    case 4:
      //SB-431542
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "SB-431542 is a TFG-beta pathway inhibitor that acts by inhibiting SMAD proteins. SB-431542 acts to direct stem cells into the ectodermal lineage (which includes the brain) by preventing differentiation into the mesodermal or endodermal lineage.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 5:
      //IWR1
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "IWR1 is a WNT pathway inhibitor. IWR1 acts to direct stem cells into forebrain by preventing differentiation into other brain regions like hindbrain or midbrain.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 6:
      //EGF
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Epidermal Growth Factor (EGF) acts as a general growth factor to promote the expansion of the neuroectoderm and increase the progenitor population. When paired with Heparin, EGF acts to stimulate the elongation of radial glial fibers, which are embryonic stem cells that create scaffolds that promote cell growth.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;
    case 7:
      //BDNF
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Brain Derived Neurotropic Factor (BDNF) acts as a growth factor that plays a role in maturation of neuronal cell types. It is thought to promote neuronal activity, network formation, and astrogenesis.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 8:
      //FGFb
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Fibroblast Growth Factor 2 (also called FGFbeta) acts as a general growth factor to promote the expansion of progenitor populations and stimulate forebrain neurogenesis.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;
    case 9:
      //NT3
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Neurotrophin-3 (NT3) is a protein that acts to stimulate neurogenesis and neuronal maturation.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;
    case 10:
      //Heperin
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Heparin is a glycosaminoglycan (a negatively-charged polysaccharide compound) that acts as an anticoagulant. It may also have a structural role as a proteoglycan (a protein) in the extracellular matrix.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 11:
      //N2
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "N2 is a supplement that acts to promote growth of neuronal cells.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 12:
      //B27
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "B27 is a supplement that supports neuronal survival. It contains retinoic acid, which is a factor that promotes maturation of cell types in the forebrain.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 13:
      //FBS
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Fetal Bovine Serum (FBS) Acts to promote the growth, survival, and maturation of cellular cultures.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;
    case 14:
      //Lipid Concentrate
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Lipid Concetrate is a concentrated form of chemically defined lipids. Needed as a lipid replacement in serum-free media.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 15:
      //PenStrep
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Penicillin-Streptomycin (PenStrep) is an antibiotic cocktail, which inhibits the growth of bacteria including E. coli.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 16:
      //Fungizone
      textSize(descriptionTextSize);
      textStyle(NORMAL);
      text(
        "Fungizone is Amphotericin B, an antifungal drug.",
        textX,
        textY,
        textXBox,
        textYBox
      );
      
      noStroke();
      break;

    case 17:
     
      image( imgSchedule, 60, 100);
       imgSchedule.resize(680, 390);
       textSize(20);
      textStyle(NORMAL);
      break;

    case 18:
      textSize(20);
      textStyle(NORMAL);
      text("In the game, you will recreate the medias one at a time\n using the 'Add to Mixture' and 'Feed Mixture'\n buttons to culture the simulated organoid.\n You have three health points, which will decrease every time you make a mistake.\n You also have 6 sterility points, which decrease whenever you feed the organoid,\n which simulates the danger of opening an incubator too many times.",
        400,
        150
      );
      text(
        "Click the schedule button above to learn how to make a brain organoid",
        textX + 350,
        textY + 220
      );
       text(
        "Click the buttons to learn more about the chemicals used in this process",
        400,
        450
      );
      break;

    default:
      textSize(descriptionTextSize);
      textWrap(WORD);
      textStyle(NORMAL);
      textSize(20);
      text("Welcome to the Neural Culture Training Game!\n Here, we begin with some undifferentiated stem cells which\n have the potential to turn into different types of organoids.\n Using the schedule tab on this page\n and the main interface in the companion sketch,\n you will work to culture a neural organoid by feeding it four different medias.\n\n ",
        400,
        120
      );
       text(
        "Click the schedule button above to learn how to make a brain organoid",
        textX + 350,
        textY + 255
      );
       text(
        "Click the buttons below to learn more about the chemicals used in this process",
        400,
        490
      );
      noStroke();
      break;
  }
}
